<?php

	// $curl = curl_init();

	// curl_setopt_array($curl, [
	// CURLOPT_PORT => "8000",
	// CURLOPT_URL => "http://localhost:8000/braso/armazem_paraiba/index.php",
	// CURLOPT_RETURNTRANSFER => true,
	// CURLOPT_ENCODING => "",
	// CURLOPT_MAXREDIRS => 10,
	// CURLOPT_TIMEOUT => 30,
	// CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	// CURLOPT_CUSTOMREQUEST => "POST",
	// CURLOPT_POSTFIELDS => "-----011000010111000001101001\r\nContent-Disposition: form-data; name=\"botao\"\r\n\r\nEntrar\r\n-----011000010111000001101001\r\nContent-Disposition: form-data; name=\"dominio\"\r\n\r\n/armazem_paraiba/index.php\r\n-----011000010111000001101001\r\nContent-Disposition: form-data; name=\"user\"\r\n\r\notavio\r\n-----011000010111000001101001\r\nContent-Disposition: form-data; name=\"password\"\r\n\r\n8788e5e7f4989bec563a21d65f9639ca\r\n-----011000010111000001101001\r\nContent-Disposition: form-data; name=\"getSessionValues\"\r\n\r\ntrue\r\n-----011000010111000001101001--\r\n",
	// CURLOPT_COOKIE => "PHPSESSID=3ip2asmqb5epkp8f1mj7p5cbk7",
	// CURLOPT_HTTPHEADER => [
	// 	"Content-Type: multipart/form-data; boundary=---011000010111000001101001",
	// 	"User-Agent: insomnia/9.2.0"
	// ],
	// ]);

	// $response = curl_exec($curl);
	// $err = curl_error($curl);

	// curl_close($curl);

	// if ($err) {
	// echo "cURL Error #:" . $err;
	// } else {
	// echo $response;
	// }