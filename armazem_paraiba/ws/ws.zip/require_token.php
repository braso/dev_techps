<?php
    declare(strict_types=1);
    require_once('vendor/autoload.php'); 
    use Firebase\JWT\JWT;